from .cli_functions import (lexinput, entry, check_levels, print_greeting, translate, lexhelp,
    alias, print_changelogs, error)

from .end_functions import rand_task, thoughts, rand_dex, end_functions_dictionary