# lexe commands changelogs

## v0.20.0

- More functionalities to the todo list

## v0.19.3

- Added a todo list

## v0.19.3

- Fixed some bugs
- Made the program clearer

## v0.19.2

- Separated the program into more files

## v0.19.1

- Separated the program into multiple files

## v0.19.0

- Added Pokemon dex randomizer

## v0.18.4

- Added changelogs
- Added sorting to help and alias commands
- Added a toggle for greetings
- Improved documentation