# Used to fully exit the script  
class ExitScript(Exception):
    pass