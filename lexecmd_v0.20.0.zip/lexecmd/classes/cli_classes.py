class CliSettings():
    remove_greetings = False